#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidgetItem>
#include <QTextCursor>
#include <QRegularExpression>
#include <algorithm>

#include "datatypes.h"



QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE





class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void search();     // 点搜索按钮时调用
    void click(QTableWidgetItem *item);      // 点击表格某一行时调用

private:  // 私有成员变量和函数
    Ui::MainWindow *ui;
    QString txt;
    QList<matchResult> wordHits;
    QList<book> books;






    void test();                                           // 试试读一个文件
    void load();

    // 读文件（备用）
    void readAllBooks();                                       // 把所有书都读进来
    void executeSearch(const QString &word);                   // 执行搜索
    void showctx(int offset, const QString &word, int file); // 显示上下文



    QList<chapterData> getchap(const QString &txt, int file);   // 从文本里提取章节
    QList<page> getpage(const QString &txt);
    // 从文本里提取页码


      // 根据位置找页码
    QString conv(const QString &name);                    // 把英文章节名转成中文
};

#endif // MAINWINDOW_H
