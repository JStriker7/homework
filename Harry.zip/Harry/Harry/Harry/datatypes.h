#ifndef DATATYPES_H
#define DATATYPES_H
#include <QMainWindow>
#include <QTableWidgetItem>
#include <QTextCursor>
#include <QRegularExpression>
#include <algorithm>


struct matchResult
{// 这个词在第几个字符的位置
    int offset;
    // 搜的是什么词
    QString word;
    int row;        // 在表格第几行
    int file;       // 在第几个文件里找到的
};


struct book
{
    QString path;
    // 文件在哪里
    QString name;
    // 书叫什么名字
    QString txt;
    // 书的全部内容
    bool ok;
    // 有没有成功读到
};

// 章节信息
struct chapterData
{    int offset;
    QString name;
    QString show;   // 显示的时候叫什么（比如第1章）
};

// 页码信息 - 记录页码位置
struct page
{ // 这个页码在第几个字符
    int offset;
    // 页码数字
    int num;
};

#endif // DATATYPES_H
