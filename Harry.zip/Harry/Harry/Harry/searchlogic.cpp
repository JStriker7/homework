#include "searchlogic.h"

QString buildContextText(const QString& fullText, const QString& word, int position)
{
    const int len = 200;
    int start = qMax(0, position - len);
    int end = qMin(fullText.length() - 1, position + word.length() + len);

    QString ctx = fullText.mid(start, end - start + 1);
    int rel = position - start;

    QString before = ctx.left(rel);
    QString high = ctx.mid(rel, word.length());
    QString after = ctx.mid(rel + word.length());

    return before + "【" + high + "】" + after;
}

void locateSection(int offset, const QList<chapterData>& chaps, const QList<page>& pages, QString& chapterName, int& pageNum)
{
    chapterName = "第1章";
    pageNum = 1;

    for (const auto& c : chaps) {
        if (c.offset <= offset)
            chapterName = c.show;
        else
            break;
    }

    for (const auto& p : pages) {
        if (p.offset <= offset)
            pageNum = p.num;
        else
            break;
    }
}
