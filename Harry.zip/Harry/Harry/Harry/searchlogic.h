#ifndef SEARCHLOGIC_H
#define SEARCHLOGIC_H
#include "datatypes.h"
#include <QString>
#include <QList>

QString buildContextText(const QString& fullText, const QString& word, int position);
void locateSection(int offset, const QList<chapterData>& chaps, const QList<page>& pages, QString& chapterName, int& pageNum);
#endif // SEARCHLOGIC_H
